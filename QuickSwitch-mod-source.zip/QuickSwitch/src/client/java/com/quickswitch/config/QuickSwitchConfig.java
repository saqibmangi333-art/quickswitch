package com.quickswitch.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Simple JSON-backed config. Every field here is user-adjustable.
 * File lives at: .minecraft/config/quickswitch.json
 * You can edit it by hand while the game is closed, or (recommended)
 * hook a Cloth Config / ModMenu screen up to it later.
 */
public class QuickSwitchConfig {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("quickswitch.json");

	// ----- Master switch (bound to a keybind, see KeyBindings) -----
	public boolean masterEnabled = true;

	// ----- Auto Totem -----
	public boolean autoTotemEnabled = true;
	/** Trigger when current health (out of 20) drops to/below this value. 6 = 3 hearts. */
	public float autoTotemHealthThreshold = 6.0f;
	/** Also trigger if incoming damage next tick would be lethal, not just low HP. */
	public boolean autoTotemPredictLethalDamage = true;

	// ----- Auto Cart -----
	public boolean autoCartEnabled = true;
	/** How many ticks to wait after placing a rail before trying to place the cart. */
	public int autoCartDelayTicks = 2;

	// ----- Mace Switch -----
	public boolean maceSwitchEnabled = true;
	/**
	 * -1 = switch back to whatever slot you were on before you picked up the mace.
	 * 0-8 = always switch to this fixed hotbar slot after a mace hit.
	 */
	public int maceSwitchTargetSlot = -1;
	/** Ticks to wait after the hit before switching (0 = instant). */
	public int maceSwitchDelayTicks = 1;

	private static QuickSwitchConfig instance;

	public static QuickSwitchConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static QuickSwitchConfig load() {
		if (Files.exists(PATH)) {
			try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
				QuickSwitchConfig loaded = GSON.fromJson(reader, QuickSwitchConfig.class);
				if (loaded != null) {
					return loaded;
				}
			} catch (IOException e) {
				com.quickswitch.QuickSwitch.LOGGER.warn("Failed to read quickswitch.json, using defaults", e);
			}
		}
		QuickSwitchConfig fresh = new QuickSwitchConfig();
		fresh.save();
		return fresh;
	}

	public void save() {
		try {
			Files.createDirectories(PATH.getParent());
			try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			com.quickswitch.QuickSwitch.LOGGER.warn("Failed to save quickswitch.json", e);
		}
	}
}
