package com.quickswitch;

import com.quickswitch.config.QuickSwitchConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

/**
 * All keybinds appear under Options -> Controls -> "QuickSwitch" like any
 * vanilla keybind category. They're unbound by default (GLFW_KEY_UNKNOWN),
 * exactly like most vanilla keys such as "Sprint" used to be — go bind
 * whatever key you want in the Controls menu.
 */
public class KeyBindings {

	private static final String CATEGORY = "key.categories.quickswitch";

	public static KeyBinding toggleMaster;
	public static KeyBinding toggleAutoTotem;
	public static KeyBinding toggleAutoCart;
	public static KeyBinding toggleMaceSwitch;

	public static void register() {
		toggleMaster = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.quickswitch.toggle_master",
				InputUtil.Type.KEYSYM,
				InputUtil.UNKNOWN_KEY.getCode(),
				CATEGORY
		));

		toggleAutoTotem = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.quickswitch.toggle_totem",
				InputUtil.Type.KEYSYM,
				InputUtil.UNKNOWN_KEY.getCode(),
				CATEGORY
		));

		toggleAutoCart = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.quickswitch.toggle_cart",
				InputUtil.Type.KEYSYM,
				InputUtil.UNKNOWN_KEY.getCode(),
				CATEGORY
		));

		toggleMaceSwitch = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.quickswitch.toggle_mace",
				InputUtil.Type.KEYSYM,
				InputUtil.UNKNOWN_KEY.getCode(),
				CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(KeyBindings::handleTick);
	}

	private static void handleTick(MinecraftClient client) {
		QuickSwitchConfig cfg = QuickSwitchConfig.get();
		boolean changed = false;

		while (toggleMaster.wasPressed()) {
			cfg.masterEnabled = !cfg.masterEnabled;
			notify(client, "QuickSwitch", cfg.masterEnabled);
			changed = true;
		}
		while (toggleAutoTotem.wasPressed()) {
			cfg.autoTotemEnabled = !cfg.autoTotemEnabled;
			notify(client, "Auto Totem", cfg.autoTotemEnabled);
			changed = true;
		}
		while (toggleAutoCart.wasPressed()) {
			cfg.autoCartEnabled = !cfg.autoCartEnabled;
			notify(client, "Auto Cart", cfg.autoCartEnabled);
			changed = true;
		}
		while (toggleMaceSwitch.wasPressed()) {
			cfg.maceSwitchEnabled = !cfg.maceSwitchEnabled;
			notify(client, "Mace Switch", cfg.maceSwitchEnabled);
			changed = true;
		}

		if (changed) {
			cfg.save();
		}
	}

	private static void notify(MinecraftClient client, String feature, boolean enabled) {
		if (client.player != null) {
			client.player.sendMessage(
					Text.literal("[QuickSwitch] " + feature + " " + (enabled ? "ON" : "OFF")),
					true // action bar, same spot vanilla uses for "Sprint"/attribute toasts
			);
		}
	}
}
