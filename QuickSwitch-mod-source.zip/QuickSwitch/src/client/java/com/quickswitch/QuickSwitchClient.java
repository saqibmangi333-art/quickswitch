package com.quickswitch;

import com.quickswitch.config.QuickSwitchConfig;
import com.quickswitch.feature.AutoCartFeature;
import com.quickswitch.feature.AutoTotemFeature;
import com.quickswitch.feature.MaceSwitchFeature;
import net.fabricmc.api.ClientModInitializer;

public class QuickSwitchClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		// Load (or create) config/quickswitch.json
		QuickSwitchConfig.get();

		KeyBindings.register();
		AutoTotemFeature.register();
		AutoCartFeature.register();
		MaceSwitchFeature.register();

		QuickSwitch.LOGGER.info("QuickSwitch client features active.");
	}
}
