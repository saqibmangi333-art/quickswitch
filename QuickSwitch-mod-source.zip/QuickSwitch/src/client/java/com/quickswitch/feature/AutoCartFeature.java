package com.quickswitch.feature;

import com.quickswitch.config.QuickSwitchConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * When you place a rail (any of the 4 rail types), this queues up a short
 * delayed action that looks for a minecart in your offhand or hotbar and
 * right-clicks the newly-placed rail with it, same as you would manually.
 *
 * This is a best-effort implementation — placement precision for minecarts
 * on curved/junction rail shapes can be finicky in vanilla too, so test it
 * and tweak autoCartDelayTicks if it ever tries to click before the rail
 * has actually synced client-side.
 */
public class AutoCartFeature {

	private record PendingPlacement(BlockPos pos, int ticksLeft) {}

	private static final Deque<PendingPlacement> QUEUE = new ArrayDeque<>();

	public static void register() {
		UseBlockCallback.EVENT.register(AutoCartFeature::onUseBlock);
		ClientTickEvents.END_CLIENT_TICK.register(AutoCartFeature::onTick);
	}

	private static ActionResult onUseBlock(net.minecraft.entity.player.PlayerEntity player,
											net.minecraft.world.World world, Hand hand, BlockHitResult hitResult) {
		QuickSwitchConfig cfg = QuickSwitchConfig.get();
		MinecraftClient client = MinecraftClient.getInstance();

		if (!world.isClient || player != client.player) return ActionResult.PASS;
		if (!cfg.masterEnabled || !cfg.autoCartEnabled) return ActionResult.PASS;

		var stack = player.getStackInHand(hand);
		boolean isRail = stack.isOf(Items.RAIL) || stack.isOf(Items.POWERED_RAIL)
				|| stack.isOf(Items.DETECTOR_RAIL) || stack.isOf(Items.ACTIVATOR_RAIL);
		if (!isRail) return ActionResult.PASS;

		// The rail usually ends up either at the clicked position (if the
		// clicked block is replaceable, e.g. grass/air) or one block in the
		// direction of the clicked face. We check both spots later.
		BlockPos clicked = hitResult.getBlockPos();
		BlockPos offset = clicked.offset(hitResult.getSide());

		// Don't let vanilla's own placement get cancelled - we only observe.
        int delay = Math.max(1, cfg.autoCartDelayTicks);
        QUEUE.add(new PendingPlacement(clicked, delay));
        QUEUE.add(new PendingPlacement(offset, delay));

		return ActionResult.PASS;
	}

	private static void onTick(MinecraftClient client) {
		if (QUEUE.isEmpty() || client.player == null || client.world == null) return;

		int size = QUEUE.size();
		for (int i = 0; i < size; i++) {
			PendingPlacement p = QUEUE.poll();
			if (p == null) continue;

			int remaining = p.ticksLeft() - 1;
			if (remaining > 0) {
				QUEUE.add(new PendingPlacement(p.pos(), remaining));
				continue;
			}
			tryPlaceCart(client, p.pos());
		}
	}

	private static void tryPlaceCart(MinecraftClient client, BlockPos pos) {
		if (client.world.getBlockState(pos).getBlock() instanceof AbstractRailBlock) {
			placeMinecartAt(client, pos);
		}
	}

	private static void placeMinecartAt(MinecraftClient client, BlockPos pos) {
		ClientPlayerEntity player = client.player;
		ClientPlayerInteractionManager im = client.interactionManager;
		if (player == null || im == null) return;

		var inv = player.getInventory();
		Hand hand;
		int originalSlot = inv.selectedSlot;
		boolean switchedSlot = false;

		if (inv.offHand.get(0).isOf(Items.MINECART)) {
			hand = Hand.OFF_HAND;
		} else {
			int cartSlot = -1;
			for (int i = 0; i < 9; i++) {
				if (inv.main.get(i).isOf(Items.MINECART)) {
					cartSlot = i;
					break;
				}
			}
			if (cartSlot == -1) return; // no minecart available, nothing to do
			hand = Hand.MAIN_HAND;
			if (cartSlot != originalSlot) {
				inv.selectedSlot = cartSlot;
				client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(cartSlot));
				switchedSlot = true;
			}
		}

		Vec3d hitVec = Vec3d.ofCenter(pos).add(0, 0.1, 0);
		BlockHitResult syntheticHit = new BlockHitResult(hitVec, Direction.UP, pos, false);
		im.interactBlock(player, hand, syntheticHit);

		if (switchedSlot) {
			inv.selectedSlot = originalSlot;
			client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(originalSlot));
		}
	}
}
