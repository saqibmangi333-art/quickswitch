package com.quickswitch.feature;

import com.quickswitch.config.QuickSwitchConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Reacts once your health drops to/below the configured threshold: finds a
 * Totem of Undying anywhere in your inventory (that isn't already in your
 * offhand) and moves it there using the exact same 3-click "pickup / place /
 * pickup" sequence a player would do by hand in the inventory screen — just
 * done in a single tick instead of manually. Nothing here bypasses server
 * validation; it's the same clicks, just faster.
 *
 * NOTE: this reacts to health that has ALREADY dropped (i.e. after a hit
 * lands), same as basically every auto-totem implementation — it then makes
 * sure the totem is in place *before* the next hit, which is what actually
 * matters. True "predict the exact killing blow before it applies" would
 * need a Mixin into the damage pipeline; left out here to keep this
 * dependency-light and easy to compile.
 */
public class AutoTotemFeature {

	private static boolean wasAboveThreshold = true;

	public static void register() {
		ClientTickEvents.END_CLIENT_TICK.register(AutoTotemFeature::onTick);
	}

	private static void onTick(MinecraftClient client) {
		QuickSwitchConfig cfg = QuickSwitchConfig.get();
		if (!cfg.masterEnabled || !cfg.autoTotemEnabled) return;
		if (client.player == null || client.interactionManager == null) return;
		// Only safe to click the player's personal screen handler when no
		// other container (chest, crafting table, etc.) is open.
		if (client.currentScreen != null) return;

		ClientPlayerEntity player = client.player;
		float health = player.getHealth();

		if (health > cfg.autoTotemHealthThreshold) {
			wasAboveThreshold = true;
			return;
		}
		// Only fire once per "drop below threshold" episode, not every tick
		// while low, so we don't spam clicks once the totem is already placed.
		if (!wasAboveThreshold) return;

		PlayerInventory inv = player.getInventory();
		ItemStack offhand = inv.offHand.get(0);
		if (offhand.isOf(Items.TOTEM_OF_UNDYING)) {
			wasAboveThreshold = false;
			return; // already set up
		}

		int totemInvIndex = findTotemSlot(inv);
		if (totemInvIndex == -1) return; // no totem to grab, nothing we can do

		int totemScreenSlot = toScreenSlot(totemInvIndex);
		int offhandScreenSlot = 45;
		int syncId = player.playerScreenHandler.syncId;

		client.interactionManager.clickSlot(syncId, totemScreenSlot, 0, SlotActionType.PICKUP, player);
		client.interactionManager.clickSlot(syncId, offhandScreenSlot, 0, SlotActionType.PICKUP, player);
		client.interactionManager.clickSlot(syncId, totemScreenSlot, 0, SlotActionType.PICKUP, player);

		wasAboveThreshold = false;
	}

	private static int findTotemSlot(PlayerInventory inv) {
		for (int i = 0; i < inv.main.size(); i++) {
			if (inv.main.get(i).isOf(Items.TOTEM_OF_UNDYING)) {
				return i;
			}
		}
		return -1;
	}

	/** PlayerInventory index (0-8 hotbar, 9-35 main) -> PlayerScreenHandler slot id. */
	private static int toScreenSlot(int invIndex) {
		if (invIndex < 9) {
			return 36 + invIndex; // hotbar
		}
		return invIndex; // main inventory rows already line up 9-35 == 9-35
	}
}
