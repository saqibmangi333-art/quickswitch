package com.quickswitch.feature;

import com.quickswitch.config.QuickSwitchConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;

/**
 * After you hit an entity with a Mace, the mace has a short recovery/cooldown
 * (its attack speed is slow), so this switches you to another weapon so you
 * can keep fighting instead of swinging with nothing. Switches back to the
 * hotbar slot you were on right before you swapped to the mace, unless you
 * set a fixed target slot in the config.
 */
public class MaceSwitchFeature {

	private static int lastNonMaceSlot = 0;
	private static int pendingDelay = -1;

	public static void register() {
		AttackEntityCallback.EVENT.register(MaceSwitchFeature::onAttack);
		ClientTickEvents.END_CLIENT_TICK.register(MaceSwitchFeature::onTick);
	}

	private static ActionResult onAttack(net.minecraft.entity.player.PlayerEntity player,
										  net.minecraft.world.World world, net.minecraft.util.Hand hand,
										  net.minecraft.entity.Entity entity,
										  net.minecraft.util.hit.EntityHitResult hitResult) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (!world.isClient || player != client.player) return ActionResult.PASS;

		QuickSwitchConfig cfg = QuickSwitchConfig.get();
		if (!cfg.masterEnabled || !cfg.maceSwitchEnabled) return ActionResult.PASS;

		if (player.getStackInHand(hand).isOf(Items.MACE)) {
			pendingDelay = Math.max(0, cfg.maceSwitchDelayTicks);
		}
		return ActionResult.PASS;
	}

	private static void onTick(MinecraftClient client) {
		if (client.player == null) return;
		var inv = client.player.getInventory();

		// Remember the last slot we were on that WASN'T a mace, so "-1"
		// (switch to previous) has somewhere sensible to go back to.
		if (!inv.getMainHandStack().isOf(Items.MACE)) {
			lastNonMaceSlot = inv.selectedSlot;
		}

		if (pendingDelay < 0) return;
		if (pendingDelay > 0) {
			pendingDelay--;
			return;
		}
		pendingDelay = -1;

		QuickSwitchConfig cfg = QuickSwitchConfig.get();
		int target = cfg.maceSwitchTargetSlot;
		if (target < 0 || target > 8) {
			target = lastNonMaceSlot;
		}
		if (target == inv.selectedSlot) return;

		inv.selectedSlot = target;
		client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(target));
	}
}
