package com.quickswitch;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QuickSwitch implements ModInitializer {

	public static final String MOD_ID = "quickswitch";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// This mod is 100% client-side (all logic lives in QuickSwitchClient).
		// This entrypoint exists only so the mod loads cleanly if it's ever
		// present alongside server files; it does nothing on a dedicated server.
		LOGGER.info("QuickSwitch loaded (client-only features will activate on the client).");
	}
}
