# QuickSwitch (Fabric mod, MC 1.21.1)

Client-side QoL mod:
- **Auto Totem** — health config threshold se niche jaate hi, inventory se totem dhoond ke offhand me daal deta hai.
- **Auto Cart** — rail place karte hi, hotbar/offhand me minecart hai toh us rail pe auto place ho jata hai.
- **Mace Switch** — mace se hit lagane ke baad, pichle hotbar slot (ya config me set kiya hua fixed slot) pe switch kar deta hai.

Sab kuch `config/quickswitch.json` se adjust hota hai, aur in-game **Options -> Controls -> QuickSwitch** me keybinds bhi mil jayenge (default sab unbound hain, khud bind karo).

## Build karne ke liye (isko yaha compile/test nahi kiya gaya hai - network access nahi tha)

1. **IntelliJ IDEA** kholo (Community edition free hai) -> `Open` -> is `QuickSwitch` folder ko select karo.
2. IntelliJ khud Gradle detect karega aur "Import Gradle Project" bolega - haan bolo. Pehli baar thoda time lagega kyunki Fabric/Minecraft dependencies download hongi (internet chahiye).
3. Agar `gradlew` nahi chal raha (wrapper jar missing hai kyunki maine offline banaya hai), toh terminal me:
   ```
   gradle wrapper --gradle-version 8.8
   ```
   (Isके liye system pe Gradle installed hona chahiye - `gradle` command. Agar nahi hai toh https://gradle.org/install/ se install karo, ya IntelliJ me right-click `build.gradle` -> "Link Gradle Project" karo, wahi wrapper bana dega.)
4. Uske baad terminal me:
   ```
   ./gradlew build
   ```
5. Built mod jar milega: `build/libs/quickswitch-1.0.0.jar`
6. Us jar ko apne `.minecraft/mods` folder me daal do (Fabric Loader + Fabric API bhi mods folder me hona chahiye - dono https://fabricmc.net se download karo, MC version 1.21.1).

## Important note

Agar tum ye kisi **public/competitive server** pe use karne ka soch rahe ho, toh check kar lena wahan ke rules - "auto totem" jaisi automation zyada tar servers pe (Hypixel jaise) ban hoti hai kyunki ye manual skill ko automate karti hai. Singleplayer ya apne khud ke server ke liye bilkul safe hai.

## Versions (gradle.properties me)

Maine 1.21.1 ke liye reasonably recent Yarn mappings aur Fabric API version daale hain, lekin ye kabhi kabhi update hote rehte hain — build se pehle ek baar https://fabricmc.net/develop/ pe check kar lena ki `yarn_mappings`, `loader_version`, aur `fabric_version` abhi bhi latest/valid hain, warna Gradle dependency resolve nahi karega.
